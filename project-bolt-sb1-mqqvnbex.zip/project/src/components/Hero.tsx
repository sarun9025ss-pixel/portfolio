import { ArrowRight, Mail } from 'lucide-react';

export default function Hero() {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center px-6 py-20 bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-4xl mx-auto text-center animate-fade-in">
        <div className="inline-block px-4 py-2 mb-6 bg-blue-100 rounded-full text-blue-700 text-sm font-medium">
          Available for opportunities
        </div>

        <h1 className="text-5xl md:text-7xl font-bold text-slate-900 mb-6 tracking-tight">
          Sarun M
        </h1>

        <p className="text-xl md:text-2xl text-slate-600 mb-8 font-medium">
          MERN Stack Developer & Cloud/DevOps Engineer
        </p>

        <p className="text-lg text-slate-600 mb-12 max-w-2xl mx-auto leading-relaxed">
          I'm a passionate full-stack developer and cloud enthusiast with over 2 years of hands-on experience
          building scalable applications, automating infrastructure, and integrating AI solutions. I enjoy solving
          complex problems with simple, elegant code.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => scrollToSection('projects')}
            className="inline-flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all hover:scale-105 shadow-lg hover:shadow-xl"
          >
            View My Work
            <ArrowRight size={20} />
          </button>

          <button
            onClick={() => scrollToSection('contact')}
            className="inline-flex items-center gap-2 px-8 py-4 bg-white text-slate-900 rounded-lg font-medium hover:bg-slate-50 transition-all hover:scale-105 shadow-lg hover:shadow-xl border-2 border-slate-200"
          >
            Get In Touch
            <Mail size={20} />
          </button>
        </div>
      </div>
    </section>
  );
}
