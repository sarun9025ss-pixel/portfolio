const skillCategories = [
  {
    title: 'Frontend',
    skills: ['React.js', 'Next.js', 'JavaScript (ES6+)', 'Tailwind CSS', 'HTML', 'CSS']
  },
  {
    title: 'Backend',
    skills: ['Node.js', 'Express.js', 'REST APIs', 'Microservices']
  },
  {
    title: 'Database',
    skills: ['MongoDB', 'PostgreSQL', 'MySQL', 'Redis']
  },
  {
    title: 'Cloud & DevOps',
    skills: ['Azure', 'AWS', 'GCP', 'Docker', 'Kubernetes (AKS)', 'Ansible', 'OpenShift', 'CI/CD (GitHub Actions, Ansible Playbook)']
  },
  {
    title: 'Monitoring',
    skills: ['Grafana', 'Prometheus', 'Zabbix']
  },
  {
    title: 'Other Tools',
    skills: ['ScraperAPI', 'Bitbucket', '1Password', 'Azure CLI']
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 px-6 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-slate-900 mb-12 text-center">Technical Skills</h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, idx) => (
            <div
              key={idx}
              className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow border border-slate-100"
            >
              <h3 className="text-xl font-bold text-slate-900 mb-4">{category.title}</h3>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, skillIdx) => (
                  <span
                    key={skillIdx}
                    className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
