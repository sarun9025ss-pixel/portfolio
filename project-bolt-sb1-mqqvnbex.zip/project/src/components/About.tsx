export default function About() {
  return (
    <section id="about" className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-slate-900 mb-12 text-center">About Me</h2>

        <div className="space-y-6 text-lg text-slate-600 leading-relaxed">
          <p>
            Sarun is a curious engineer who loves building things that make an impact. He has strong experience
            working with JavaScript, Node.js, React, and modern cloud platforms like Azure, AWS, and GCP. His
            career blends both software development and DevOps, which helps him understand the full journey —
            from idea to deployment.
          </p>

          <p>
            I'm always exploring new technologies, automating workflows, and collaborating with amazing people
            to bring ideas to life.
          </p>
        </div>
      </div>
    </section>
  );
}
