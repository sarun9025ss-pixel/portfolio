import { GraduationCap, Languages } from 'lucide-react';

export default function Education() {
  return (
    <section id="education" className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-slate-900 mb-12 text-center">Education & Languages</h2>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-slate-50 p-8 rounded-xl border border-slate-200">
            <div className="flex items-center gap-3 mb-4">
              <GraduationCap className="text-blue-600" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Education</h3>
            </div>

            <p className="text-lg font-semibold text-slate-800 mb-2">
              Bachelor's Degree in Computer Science
            </p>

            <p className="text-slate-600">
              Trefs Academy College of Arts and Science, Tirupur
            </p>
          </div>

          <div className="bg-slate-50 p-8 rounded-xl border border-slate-200">
            <div className="flex items-center gap-3 mb-4">
              <Languages className="text-blue-600" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Languages</h3>
            </div>

            <ul className="space-y-2 text-slate-600">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                Malayalam (Native)
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                Tamil (Fluent)
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-blue-600 rounded-full"></span>
                English (Conversational)
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
