import { Briefcase } from 'lucide-react';

export default function Experience() {
  return (
    <section id="experience" className="py-20 px-6 bg-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl font-bold text-slate-900 mb-12 text-center">Experience</h2>

        <div className="relative pl-8 border-l-2 border-blue-200">
          <div className="absolute -left-3 top-0 w-6 h-6 bg-blue-600 rounded-full"></div>

          <div className="mb-8">
            <div className="flex items-start gap-3 mb-4">
              <Briefcase className="text-blue-600 mt-1" size={24} />
              <div>
                <h3 className="text-2xl font-bold text-slate-900">App Innovation Technology</h3>
                <p className="text-slate-600 font-medium">Coimbatore</p>
              </div>
            </div>

            <p className="text-blue-600 font-medium mb-2">
              June 2023 – September 2025 (2 years 3 months)
            </p>

            <p className="text-lg font-semibold text-slate-800 mb-4">
              MERN Stack Developer & Cloud Engineer
            </p>

            <p className="text-slate-600 leading-relaxed">
              During my time at App Innovation Technology, I worked across multiple projects, combining
              full-stack development with DevOps automation. I developed scalable web apps using React and
              Node.js, deployed services to Azure and AWS, managed CI/CD pipelines, and integrated AI-based
              automation features for clients.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
