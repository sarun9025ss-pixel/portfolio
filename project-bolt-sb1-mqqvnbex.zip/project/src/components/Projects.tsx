import { ExternalLink } from 'lucide-react';

const projects = [
  {
    name: 'Yadara & MyTickets',
    timeline: 'June 2023 – Nov 2023',
    description: 'Event and movie ticket booking platform with user login (Google & Meta) and admin management portal.',
    stack: ['Next.js', 'Node.js', 'PostgreSQL', 'OpenSearch', 'AutoScaling VM']
  },
  {
    name: 'Instant.ro',
    timeline: 'Dec 2023 – Oct 2024',
    description: 'AI-powered vehicle marketplace for Romanian users. Integrated Azure OpenAI to extract car details from images and automated data scraping from other sites.',
    stack: ['React.js', 'Node.js', 'MongoDB', 'Redis', 'PHP', 'ScraperAPI', 'Azure MySQL']
  },
  {
    name: 'Footprints.ai',
    timeline: 'Nov 2023 – May 2024',
    description: 'High-traffic user tracking and analytics system using Redis and MongoDB, deployed on Azure, AWS, and GCP.',
    stack: ['React.js', 'Node.js', 'Redis', 'MongoDB', 'Ansible', 'AKS', 'Grafana']
  },
  {
    name: 'CSI Automation',
    timeline: 'Jun 2024 – Sep 2025',
    description: 'Automation platform to manage physical and virtual machines using OpenShift and Ansible Automation Platform.',
    stack: ['OpenShift', 'Ansible', 'Bitbucket', 'Python', '1Password', 'Grafana']
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 px-6 bg-slate-50">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-slate-900 mb-12 text-center">Featured Projects</h2>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, idx) => (
            <div
              key={idx}
              className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-all border border-slate-100 hover:border-blue-200 group"
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {project.name}
                </h3>
                <ExternalLink className="text-slate-400 group-hover:text-blue-600 transition-colors" size={20} />
              </div>

              <p className="text-sm text-blue-600 font-medium mb-4">{project.timeline}</p>

              <p className="text-slate-600 mb-6 leading-relaxed">{project.description}</p>

              <div className="flex flex-wrap gap-2">
                {project.stack.map((tech, techIdx) => (
                  <span
                    key={techIdx}
                    className="px-3 py-1 bg-slate-100 text-slate-700 rounded-md text-sm font-medium"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
