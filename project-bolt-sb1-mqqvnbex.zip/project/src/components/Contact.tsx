import { Mail, Phone, MessageCircle } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 px-6 bg-slate-50">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold text-slate-900 mb-6">Let's Connect</h2>

        <p className="text-lg text-slate-600 mb-12 max-w-2xl mx-auto">
          If you'd like to talk about tech, projects, or opportunities — drop me a message anytime!
        </p>

        <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <a
            href="mailto:sarun9025ss@gmail.com"
            className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all border border-slate-200 hover:border-blue-300 group"
          >
            <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
              <Mail className="text-blue-600" size={24} />
            </div>
            <div className="text-left">
              <p className="text-sm text-slate-500 font-medium">Email</p>
              <p className="text-slate-900 font-semibold">sarun9025ss@gmail.com</p>
            </div>
          </a>

          <a
            href="tel:+919025220184"
            className="flex items-center gap-4 p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-all border border-slate-200 hover:border-blue-300 group"
          >
            <div className="p-3 bg-blue-50 rounded-lg group-hover:bg-blue-100 transition-colors">
              <Phone className="text-blue-600" size={24} />
            </div>
            <div className="text-left">
              <p className="text-sm text-slate-500 font-medium">Phone</p>
              <p className="text-slate-900 font-semibold">9025220184</p>
            </div>
          </a>
        </div>

        <div className="mt-12 p-8 bg-gradient-to-br from-blue-50 to-slate-50 rounded-2xl border border-blue-100">
          <MessageCircle className="text-blue-600 mx-auto mb-4" size={48} />
          <p className="text-slate-700 text-lg">
            Open to freelance projects, collaborations, and full-time opportunities
          </p>
        </div>
      </div>
    </section>
  );
}
